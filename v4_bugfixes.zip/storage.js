// src/firebase/storage.js  (Cloudinary — free, no credit card)
import { addDocMeta, deleteDocMeta } from './firestore'

const CLOUD  = import.meta.env.VITE_CLOUDINARY_CLOUD_NAME
const PRESET = import.meta.env.VITE_CLOUDINARY_UPLOAD_PRESET

// ── Core upload function ──────────────────────────────────────
// resourceType: 'auto' for images/docs, 'raw' for PDFs
// Using 'raw' for PDFs is critical — Cloudinary's 'auto' mode
// can transform PDFs and corrupt the file extension on download.
function cloudinaryUpload(file, folder, onProgress = () => {}, resourceType = 'auto') {
  return new Promise((resolve, reject) => {
    if (!CLOUD || !PRESET) {
      reject(new Error(
        'Cloudinary not configured. Add VITE_CLOUDINARY_CLOUD_NAME ' +
        'and VITE_CLOUDINARY_UPLOAD_PRESET to your .env file.'
      ))
      return
    }

    // Clean filename — remove spaces, keep extension intact
    const safeName  = file.name.replace(/\s/g, '_')
    const publicId  = `${Date.now()}_${safeName}`

    const fd = new FormData()
    fd.append('file',          file)
    fd.append('upload_preset', PRESET)
    fd.append('folder',        folder)
    fd.append('public_id',     publicId)

    const xhr = new XMLHttpRequest()
    // KEY FIX: use /raw/ endpoint for PDFs so the file is stored
    // exactly as-is with no Cloudinary transformation applied.
    // For images/other docs use /auto/ as before.
    const endpoint = `https://api.cloudinary.com/v1_1/${CLOUD}/${resourceType}/upload`
    xhr.open('POST', endpoint, true)

    xhr.upload.onprogress = e => {
      if (e.lengthComputable) onProgress(Math.round((e.loaded / e.total) * 100))
    }

    xhr.onload = () => {
      if (xhr.status >= 200 && xhr.status < 300) {
        const data = JSON.parse(xhr.responseText)

        // For raw uploads, Cloudinary doesn't add a format field.
        // Build a clean download URL that forces .pdf extension.
        let downloadUrl = data.secure_url
        if (resourceType === 'raw') {
          // Ensure URL ends with the correct filename including .pdf
          // Strip any Cloudinary-appended format suffix just in case
          downloadUrl = data.secure_url.replace(/\.[^/.]+$/, '') + '.pdf'
        }

        resolve({
          url:      downloadUrl,
          publicId: data.public_id,
          name:     file.name,       // always use original filename
          size:     file.size,
          type:     file.type,
          format:   resourceType === 'raw' ? 'pdf' : (data.format || ''),
        })
      } else {
        try {
          const err = JSON.parse(xhr.responseText)
          reject(new Error(err.error?.message || 'Upload failed'))
        } catch {
          reject(new Error(`Upload failed with status ${xhr.status}`))
        }
      }
    }

    xhr.onerror = () => reject(new Error('Network error during upload'))
    xhr.send(fd)
  })
}

// ── Client documents (images + PDFs mixed) ────────────────────
export async function uploadClientDocument(clientId, file, onProgress = () => {}) {
  const isPdf = file.type === 'application/pdf' || file.name.toLowerCase().endsWith('.pdf')
  // Use 'raw' for PDFs, 'auto' for images
  const resourceType = isPdf ? 'raw' : 'auto'
  const meta = await cloudinaryUpload(
    file,
    `gohil_investments/clients/${clientId}`,
    onProgress,
    resourceType
  )
  await addDocMeta(clientId, meta)
  return meta
}

export async function deleteClientDocument(clientId, docId) {
  await deleteDocMeta(clientId, docId)
}

// ── Policy PDF upload ─────────────────────────────────────────
// Always uses 'raw' resource type — PDFs only.
// Returns { url, name } — caller must call savePolicyPdfUrl() to persist.
export async function uploadPolicyPdf(policyId, file, onProgress = () => {}) {
  const isPdf = file.type === 'application/pdf' || file.name.toLowerCase().endsWith('.pdf')
  if (!isPdf) {
    throw new Error('Only PDF files are allowed for policy documents.')
  }
  const meta = await cloudinaryUpload(
    file,
    `gohil_investments/policies/${policyId}`,
    onProgress,
    'raw'   // ← always raw for policy PDFs
  )
  return { url: meta.url, name: meta.name }
}
