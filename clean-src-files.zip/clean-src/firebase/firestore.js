import {
  collection, doc, addDoc, getDoc, getDocs, updateDoc,
  deleteDoc, query, where, orderBy, serverTimestamp,
  onSnapshot, writeBatch
} from 'firebase/firestore'
import { db } from './config'

const CLIENTS   = 'clients'
const POLICIES  = 'policies'
const PROPOSALS = 'proposals'
const DOCS_META = 'documents'

// ── CLIENTS ──────────────────────────────────────────────────
export const clientsRef = () => collection(db, CLIENTS)

export async function addClient(data) {
  return addDoc(clientsRef(), { ...data, createdAt: serverTimestamp(), updatedAt: serverTimestamp() })
}
export async function getClient(id) {
  const snap = await getDoc(doc(db, CLIENTS, id))
  return snap.exists() ? { id: snap.id, ...snap.data() } : null
}
export async function getAllClients() {
  const snap = await getDocs(query(clientsRef(), orderBy('createdAt', 'desc')))
  return snap.docs.map(d => ({ id: d.id, ...d.data() }))
}
export async function updateClient(id, data) {
  return updateDoc(doc(db, CLIENTS, id), { ...data, updatedAt: serverTimestamp() })
}
export async function deleteClient(id) {
  const pols = await getDocs(query(collection(db, POLICIES), where('clientId', '==', id)))
  const batch = writeBatch(db)
  pols.docs.forEach(d => batch.delete(d.ref))
  batch.delete(doc(db, CLIENTS, id))
  return batch.commit()
}
export function subscribeClients(callback) {
  const q = query(clientsRef(), orderBy('createdAt', 'desc'))
  return onSnapshot(q, snap => callback(snap.docs.map(d => ({ id: d.id, ...d.data() }))))
}

// ── POLICIES ─────────────────────────────────────────────────
export const policiesRef = () => collection(db, POLICIES)

export async function addPolicy(data) {
  return addDoc(policiesRef(), { ...data, createdAt: serverTimestamp(), updatedAt: serverTimestamp() })
}
export async function getPolicy(id) {
  const snap = await getDoc(doc(db, POLICIES, id))
  return snap.exists() ? { id: snap.id, ...snap.data() } : null
}
export async function getAllPolicies() {
  const snap = await getDocs(query(policiesRef(), orderBy('expiryDate', 'asc')))
  return snap.docs.map(d => ({ id: d.id, ...d.data() }))
}
export async function getPoliciesForClient(clientId) {
  const snap = await getDocs(query(policiesRef(), where('clientId', '==', clientId)))
  return snap.docs.map(d => ({ id: d.id, ...d.data() }))
}
export async function updatePolicy(id, data) {
  return updateDoc(doc(db, POLICIES, id), { ...data, updatedAt: serverTimestamp() })
}
export async function deletePolicy(id) {
  return deleteDoc(doc(db, POLICIES, id))
}
export function subscribePolicies(callback) {
  const q = query(policiesRef(), orderBy('expiryDate', 'asc'))
  return onSnapshot(q, snap => callback(snap.docs.map(d => ({ id: d.id, ...d.data() }))))
}

// ── PROPOSALS ────────────────────────────────────────────────
export const proposalsRef = () => collection(db, PROPOSALS)

export async function addProposal(data) {
  return addDoc(proposalsRef(), { ...data, createdAt: serverTimestamp(), updatedAt: serverTimestamp() })
}
export async function getAllProposals() {
  const snap = await getDocs(query(proposalsRef(), orderBy('createdAt', 'desc')))
  return snap.docs.map(d => ({ id: d.id, ...d.data() }))
}
export async function updateProposal(id, data) {
  return updateDoc(doc(db, PROPOSALS, id), { ...data, updatedAt: serverTimestamp() })
}
export async function deleteProposal(id) {
  return deleteDoc(doc(db, PROPOSALS, id))
}

// ── DOCUMENT METADATA ────────────────────────────────────────
export async function addDocMeta(clientId, meta) {
  return addDoc(collection(db, CLIENTS, clientId, DOCS_META), { ...meta, uploadedAt: serverTimestamp() })
}
export async function getDocMeta(clientId) {
  const snap = await getDocs(collection(db, CLIENTS, clientId, DOCS_META))
  return snap.docs.map(d => ({ id: d.id, ...d.data() }))
}
export async function deleteDocMeta(clientId, docId) {
  return deleteDoc(doc(db, CLIENTS, clientId, DOCS_META, docId))
}
