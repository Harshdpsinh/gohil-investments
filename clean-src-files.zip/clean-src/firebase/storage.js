import { addDocMeta, deleteDocMeta } from './firestore'

const CLOUD  = import.meta.env.VITE_CLOUDINARY_CLOUD_NAME
const PRESET = import.meta.env.VITE_CLOUDINARY_UPLOAD_PRESET

export function uploadClientDocument(clientId, file, onProgress = () => {}) {
  return new Promise((resolve, reject) => {
    if (!CLOUD || !PRESET) {
      reject(new Error('Cloudinary is not configured. Add VITE_CLOUDINARY_CLOUD_NAME and VITE_CLOUDINARY_UPLOAD_PRESET to your .env file.'))
      return
    }
    const formData = new FormData()
    formData.append('file',          file)
    formData.append('upload_preset', PRESET)
    formData.append('folder',        `gohil_investments/clients/${clientId}`)
    formData.append('public_id',     `${Date.now()}_${file.name.replace(/\s/g, '_')}`)

    const xhr = new XMLHttpRequest()
    xhr.open('POST', `https://api.cloudinary.com/v1_1/${CLOUD}/auto/upload`, true)
    xhr.upload.onprogress = e => {
      if (e.lengthComputable) onProgress(Math.round((e.loaded / e.total) * 100))
    }
    xhr.onload = async () => {
      if (xhr.status >= 200 && xhr.status < 300) {
        const data = JSON.parse(xhr.responseText)
        const meta = { name: file.name, url: data.secure_url, publicId: data.public_id, size: file.size, type: file.type }
        await addDocMeta(clientId, meta)
        resolve(meta)
      } else {
        const err = JSON.parse(xhr.responseText)
        reject(new Error(err.error?.message || 'Upload failed'))
      }
    }
    xhr.onerror = () => reject(new Error('Network error during upload'))
    xhr.send(formData)
  })
}

export async function deleteClientDocument(clientId, docId) {
  await deleteDocMeta(clientId, docId)
}
